const bearImg = "https://gallery.yopriceville.com/var/resizes/Free-Clipart-Pictures/Valentine%27s-Day-PNG/Cute_Teddy_Bear_with_Heart_PNG_Clipart.png?m=1605758401";

const loveImg = "https://toppng.com/free-image/heart-cute-png-vector-library-library-kawaii-cute-pink-heart-PNG-free-PNG-Images_163934";